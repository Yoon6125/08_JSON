package com.peisia.controller;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.peisia.MHW.charmDto.MHWcharmDto;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/MHW/*")
@AllArgsConstructor
public class MHWcharmController {

	@RequestMapping("/M")
	public void M(Model model) {
		//// 우리나라 공공 api ////
		// 인코딩 인증키
		String API_KEY = "313";
		String API_URL = "https://mhw-db.com/charms/" + API_KEY;

		RestTemplate restTemplate = new RestTemplate();

		//// **** 중요 **** uri
		URI uri = null; // java.net.URI 임포트 하셈
		try {
			uri = new URI(API_URL); // URI 클래스는 URL에 대한 유효성 검사, 구성요소 추출, 보안(특수문자, 공백 처리 등)을 도와줌
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		String s = restTemplate.getForObject(uri, String.class); //
		log.info("====== 우리나라 날씨 잘 나오나? " + s);

		MHWcharmDto kw = restTemplate.getForObject(uri, MHWcharmDto.class); // 자기 클래스로 바꾸시오..
		log.info("==== json ==== : 이름 : " + kw.name);
		log.info("==== json ==== : 장비 id : " + kw.id);

		model.addAttribute("name", kw.name);

	}

	@GetMapping("/index.html")
	public void index() {

	}
}
