package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;
import com.peisia.dto.SearchDto;
import com.peisia.mapper.GuestMapper;

import lombok.Data;

//페이징 및 페이징블럭 처리 메소드
@Data
public class BoardListProcessor {
	private GuestMapper mapper;
	private ArrayList<GuestDto> post;
	public int totalPage = 0;
	public int currentPage = 1;
	private String htmlPageList;

	// 페이징 블럭 처리
	// 1-9 블럭 총 갯수 구하기
	int totalBlock = 0;

	// 2-9 현재 블럭 구하기
	int currnetBlockNo = 0;

	// 3-9 블럭 시작 페이지 구하기
	int blockStartNo = 0;

	// 4-9 블럭 끝 페이지 구하기
	int blockEndNo = 0;

	// 5-9 이전/다음 관련 초기화
	int prevPage = 0;
	int nextPage = 0;

	// 6-9 이전/다음 관련 계산 처리
	boolean hasPrev = true;
	boolean hasNext = true;

	// 페이징 메소드
	public BoardListProcessor(GuestMapper mapper, int currentPage, String path, String searchWord) {
		super();
		this.mapper = mapper;
		this.currentPage = currentPage;
		this.totalPage = 0;

		if (searchWord == null || searchWord.equals("null")) {
			totalPage = getPageCount();
			getList();
		} else {
			totalPage = getSearchPageCount(searchWord);
			getSearchList(searchWord);
		}

		// 블럭 처리, 블럭의 총 갯수 구하기
		totalBlock = (int) Math.ceil((double) totalPage / 5);

		// 블럭 처리 , 현재 블럭 구하기
		currnetBlockNo = (int) Math.ceil((double) this.currentPage / 5);

		// 블럭 처리, 블럭 시작 페이지 구하기
		blockStartNo = (currnetBlockNo - 1) * 5 + 1;

		// 블럭 처리, 블럭 끝 페이지 번호 구하기
		blockEndNo = currnetBlockNo * 5;

		// 블럭 마지막 번호가 전체 페이지 번호보다 클 시 예외 처리
		if (blockEndNo > totalPage) {
			blockEndNo = totalPage;
		}

		// 이전/다음 관련 계산 처리
		// 현재 블럭에서 이전/다음 이 가능한지 계산하고 가능 여부 저장
		if (currnetBlockNo == 1) {
			hasPrev = false;
		} else {
			hasPrev = true;

			// 이전 블록 이동시 몇 페이지로 이동할지 정하기
			// 이전 블럭의 마지막 페이지로 이동 , 공식: (현재블럭-1)* 블럭당 페이지 수
			prevPage = (currnetBlockNo - 1) * 5;
		}
		if (currnetBlockNo < totalBlock) {
			hasNext = true;

			// 다음 블럭 이동시 몇 페이지로 이동할지 정하기
			// 다음 블럭의 첫 페이지로 이동하는거로 구현 , 공식: 현재 블럭 번호 * 블럭당 페이지수 +1

			nextPage = currnetBlockNo * 5 + 1;
		} else {
			hasNext = false;
		}

		this.htmlPageList = getHtmlPageList(path, searchWord);
	}

	// 리스트 가져오는 메소드 선언
	public void getList() {
		int startIndex = (currentPage - 1) * 5;
		post = mapper.getList(startIndex);
	}

	// 리스트 가져오는 메소드(검색용)
	public void getSearchList(String searchWord) {
		int startIndex = (currentPage - 1) * 5;
		SearchDto dto = new SearchDto();
		dto.setSearchWord(searchWord);
		dto.setLimitIndex(startIndex);
		post = mapper.getSearchList(dto);
	}

	// 총 페이지 수 구하는 메소드
	public int getPageCount() {
		int totalPageCount = 0;
		int count = mapper.getPostCount();
		if (count % 5 == 0) {
			totalPageCount = count / 5;
		} else {
			totalPageCount = count / 5 + 1;
		}

		return totalPageCount;
	}

	// 총 페이지 수 구하는 메소드(검색용)
	public int getSearchPageCount(String searchWord) {
		int totalPageCount = 0;
		int count = mapper.getSearchPostCount(searchWord);
		if (count % 5 == 0) {
			totalPageCount = count / 5;
		} else {
			totalPageCount = count / 5 + 1;
		}
		return totalPageCount;
	}

	// 글 리스트 객체 얻는 함수
	public ArrayList<GuestDto> getPost() {
		return post;
	}

	// 글 리스트 객체 얻는 함수(검색용)
	public ArrayList<GuestDto> getSearchPost(SearchDto dto) {
		return post;
	}

	/*
	 * // 페이지 리스트를 출력하기 위한 html 리턴 메소드 public String getHtmlPageList(String path) {
	 * StringBuilder html = new StringBuilder();
	 * 
	 * if (hasPrev) {
	 * html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>이전</a>",
	 * path, prevPage)); }
	 * 
	 * for (int i = blockStartNo; i <= blockEndNo; i++) { html.append(String.
	 * format("<a href='%s/guest/getList?currentPage=%d'>%d</a>&nbsp;&nbsp;", path,
	 * i, i)); }
	 * 
	 * if (hasNext) {
	 * html.append(String.format("<a href='%s/guest/getList?currnePage=%d'>다음</a>",
	 * path, nextPage)); } return html.toString(); }
	 */
	public String getHtmlPageList(String path, String searchWord) {
		StringBuilder html = new StringBuilder();

		// 이전 블럭 이동 링크 생성
		if (hasPrev) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>이전</a>", path, prevPage));
			} else {
				html.append(String.format("<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>이전</a>", path,
						prevPage, searchWord));
			}
		}

		// 현재 블럭 페이지 링크 생성
		for (int i = blockStartNo; i <= blockEndNo; i++) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>%d</a>&nbsp;&nbsp;", path, i, i));
			} else {
				html.append(String.format(
						"<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>%d</a>&nbsp;&nbsp;", path, i,
						searchWord, i));
			}
		}

		// 다음 블럭 이동 링크 생성
		if (hasNext) {
			if (searchWord == null || searchWord.equals("null")) {
				html.append(String.format("<a href='%s/guest/getList?currentPage=%d'>다음</a>", path, nextPage));
			} else {
				html.append(String.format("<a href='%s/guest/getSearchList?currentPage=%d&searchWord=%s'>다음</a>", path,
						nextPage, searchWord));
			}
		}
		return html.toString();
	}
}
