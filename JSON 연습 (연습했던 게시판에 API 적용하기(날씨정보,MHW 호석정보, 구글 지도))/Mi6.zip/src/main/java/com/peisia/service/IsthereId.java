package com.peisia.service;

import com.peisia.mapper.GuestMapper;

import lombok.Data;

@Data
public class IsthereId {
	private boolean isthereId = true;
	private GuestMapper mapper;

	public IsthereId(GuestMapper mapper, String bid) {
		if (mapper.selectId(bid) == true) {
			isthereId = true;
		} else {
			isthereId = false;
		}

	}

}
