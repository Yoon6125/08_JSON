package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.mapper.TestMapper;
import com.peisia.spring.dto.Testdto;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class TestServiceImpl implements TestService {
	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;

	@Override
	public String getOne() {
		Testdto tvo = mapper.dto1();
		String one = tvo.getStr_data();
		return one;
	}

	@Override
	public String getTwo() {
		Testdto tvo = mapper.dto2();
		String two = tvo.getStr_data();
		return two;
	}
}
