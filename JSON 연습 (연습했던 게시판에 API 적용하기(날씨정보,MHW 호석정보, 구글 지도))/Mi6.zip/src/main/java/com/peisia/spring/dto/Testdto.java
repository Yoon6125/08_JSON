package com.peisia.spring.dto;

import lombok.Data;

@Data
public class Testdto {
	private Long no;
	private String str_data;
}