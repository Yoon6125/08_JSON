
package com.peisia.MHW.charmDto;

public class Item {

	public Integer id;
	public Integer rarity;
	public Integer carryLimit;
	public Integer value;
	public String name;
	public String description;

}
