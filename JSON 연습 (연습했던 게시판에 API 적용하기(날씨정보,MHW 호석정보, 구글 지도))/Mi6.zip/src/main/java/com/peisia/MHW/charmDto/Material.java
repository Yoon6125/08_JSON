
package com.peisia.MHW.charmDto;

public class Material {

	public Integer quantity;
	public Item item;

}
