
package com.peisia.MHW.charmDto;

import java.util.List;

public class MHWcharmDto {

	public Integer id;
	public String name;
	public List<Rank> ranks;

}
