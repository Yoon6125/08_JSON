
package com.peisia.MHW.charmDto;

import java.util.List;

public class Rank {

	public Integer level;
	public Integer rarity;
	public String name;
	public List<Skill> skills;
	public Crafting crafting;

}
