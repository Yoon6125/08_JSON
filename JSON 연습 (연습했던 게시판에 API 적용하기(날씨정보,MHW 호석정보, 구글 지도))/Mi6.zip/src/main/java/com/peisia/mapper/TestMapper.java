package com.peisia.mapper;

import com.peisia.spring.dto.Testdto;

public interface TestMapper {
	public Testdto dto1();

	public Testdto dto2();

	public Testdto dto3();

	public Testdto dto4();
}
